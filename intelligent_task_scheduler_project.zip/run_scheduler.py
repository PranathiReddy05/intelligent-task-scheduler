from datetime import date, timedelta
from intelligent_task_scheduler import Task, Scheduler

if __name__ == "__main__":
    tasks = [
        Task("Finish AI lab", deadline=date.today() + timedelta(days=2), priority=5, effort=4),
        Task("Workout", deadline=date.today() + timedelta(days=1), priority=2, effort=1),
        Task("Resume update", deadline=date.today() + timedelta(days=3), priority=4, effort=2),
    ]
    schedule = Scheduler().create_schedule(tasks)
    Scheduler.pretty_print(schedule)
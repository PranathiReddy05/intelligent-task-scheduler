
"""
Intelligent Task Scheduler
Author: Pranathi | Date: July 7, 2025

This script schedules tasks by balancing deadlines, priorities, and effort hours.


Description
-----------
A lightweight yet powerful task‑scheduling engine that turns a list of
tasks (deadline, priority, effort) into an optimized daily/weekly plan.

Key Features
------------
* Human‑centric: honours a fixed number of working hours per day.
* Fast       : pure‑Python, O(N log N) greedy algorithm. No heavy deps.
* Robust     : surfaces unschedulable tasks early (with clear errors).
* Extensible : scoring weights, work hours, start date are configurable.

Public API
----------
>>> from intelligent_task_scheduler import Task, Scheduler
>>> tasks = [
...     Task('Draft proposal', deadline=date(2025, 7, 10), priority=5, effort=6),
...     Task('Email replies',   deadline=date(2025, 7, 8),  priority=3, effort=1.5),
... ]
>>> sched = Scheduler().create_schedule(tasks)
>>> Scheduler.pretty_print(sched)

License
-------
MIT License (see LICENSE file).
"""

from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Dict, Iterable, List, Tuple

# ─────────────────────────────────────────────────────────────────────────────
# Data Models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass(order=False, frozen=True, slots=True)
class Task:
    """A unit of work to be scheduled.

    Parameters
    ----------
    name      : str
        Human‑readable label.
    deadline  : datetime.date
        Latest calendar day by which the task must be finished (inclusive).
    priority  : int, default=3
        Importance on a 1‑5 scale (5 = critical).
    effort    : float, default=1.0
        Estimated effort in **hours** (positive number).
    """

    name: str
    deadline: date
    priority: int = field(default=3)
    effort: float = field(default=1.0)

    def __post_init__(self):
        if not (1 <= self.priority <= 5):
            raise ValueError("priority must be between 1 and 5 (inclusive)")
        if self.effort <= 0:
            raise ValueError("effort must be a positive number of hours")
        if not isinstance(self.deadline, date):
            raise TypeError("deadline must be a datetime.date instance")

    # Lightweight helpers (not used by scheduler but nice for users)
    def days_until_deadline(self, from_date: date | None = None) -> int:
        from_date = from_date or date.today()
        return (self.deadline - from_date).days

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.name} (P{self.priority}, {self.effort:g}h, DL {self.deadline})"

@dataclass(slots=True)
class Block:
    """Portion of a task assigned to a given day."""

    task_name: str
    hours: float

    def __repr__(self) -> str:  # pragma: no cover
        return f"{self.task_name} ({self.hours:g}h)"

# ─────────────────────────────────────────────────────────────────────────────
# Core Scheduler
# ─────────────────────────────────────────────────────────────────────────────

class Scheduler:
    """Greedy daily scheduler with a tunable priority‑urgency scoring.

    The algorithm:
    1. Score each task = w_priority * priority + w_urgency * 1/days_left.
    2. Use a max‑heap to pop tasks in order of score (highest first).
    3. Fill working days from *start_date* onward.
    4. Split tasks across multiple days if they exceed day's remaining hours.

    Complexity: O(N log N) where N is number of tasks.
    """

    def __init__(
        self,
        working_hours_per_day: float = 8.0,
        *,
        score_weights: Tuple[float, float] = (0.7, 0.3),
        start_date: date | None = None,
    ) -> None:
        if working_hours_per_day <= 0:
            raise ValueError("working_hours_per_day must be positive")
        self.working_hours = working_hours_per_day
        self.w_priority, self.w_urgency = score_weights
        self.start_date = start_date or date.today()

    # ─────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────

    def create_schedule(self, tasks: Iterable[Task]) -> Dict[date, List[Block]]:
        tasks = list(tasks)
        self._validate(tasks)

        # Build a max‑heap based on scoring
        heap: List[Tuple[float, Task]] = []
        for t in tasks:
            score = self._score(t)
            heapq.heappush(heap, (-score, t))  # negate for max‑heap

        schedule: Dict[date, List[Block]] = {}
        capacity_used: Dict[date, float] = {}

        while heap:
            _neg_score, task = heapq.heappop(heap)
            remaining = task.effort
            day = max(self.start_date, date.today())  # schedule from today

            while remaining > 1e-6:
                if day > task.deadline:
                    raise RuntimeError(
                        f"Task '{task.name}' cannot be completed before its deadline ({task.deadline})"
                    )
                available = self.working_hours - capacity_used.get(day, 0.0)
                if available <= 1e-6:  # No room left; move to next day
                    day += timedelta(days=1)
                    continue

                chunk = min(available, remaining)
                schedule.setdefault(day, []).append(Block(task.name, chunk))
                capacity_used[day] = capacity_used.get(day, 0.0) + chunk
                remaining -= chunk
            # end while task
        # end while heap

        return schedule

    @staticmethod
    def pretty_print(schedule: Dict[date, List[Block]], working_hours: float | None = None) -> None:
        """Nicely print schedule to stdout."""
        ruler = "─" * 50
        print(ruler)
        for day in sorted(schedule):
            blocks = schedule[day]
            filled = sum(b.hours for b in blocks)
            if working_hours:
                print(f"{day:%A, %d %b %Y}  –  {filled:g}h / {working_hours:g}h")
            else:
                print(f"{day:%A, %d %b %Y}  –  {filled:g}h")
            for blk in blocks:
                print(f"   • {blk}")
            print()
        print(ruler)

    # ─────────────────────────────────────────────────────────────────────
    # Internal helpers
    # ─────────────────────────────────────────────────────────────────────

    def _validate(self, tasks: List[Task]) -> None:
        if not tasks:
            raise ValueError("No tasks provided")
        for t in tasks:
            if t.deadline < self.start_date:
                raise ValueError(f"Task '{t.name}' has a deadline in the past ({t.deadline})")

    def _score(self, task: Task) -> float:
        days_left = (task.deadline - self.start_date).days + 1  # +1 to avoid divide‑by‑zero
        urgency = 1 / days_left
        return self.w_priority * task.priority + self.w_urgency * (urgency * 5)

# ─────────────────────────────────────────────────────────────────────────────
# Convenience CLI demo
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    from random import randint, uniform

    today = date.today()
    demo_tasks = [
        Task(
            name=f"Task #{i}",
            deadline=today + timedelta(days=randint(1, 7)),
            priority=randint(1, 5),
            effort=round(uniform(1, 6), 1),
        )
        for i in range(1, 8)
    ]

    print("Demo tasks:")
    for t in demo_tasks:
        print(f"  {t}")
    print()

    sched = Scheduler().create_schedule(demo_tasks)
    Scheduler.pretty_print(sched, working_hours=8.0)
